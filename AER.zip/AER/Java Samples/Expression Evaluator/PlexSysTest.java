/*
Assignment:
Write a program to parse and evaluate arithmetic expressions.
Your problem should support addition and multiplication at a minimum.
You input will be text similar to the following:
  1 + 1
  (3 + 4) * 6
  (1 * 4) + (5 * 2)
Your output should be the computed value of the expression.
Write your program in an Object Oriented fashion and be prepared to show us
your code and discuss your solution. Do not use the "Shunting Yard" algorithm.

Assumptions about requirements:
  - Supporting addition and multiplication only
  - Not supporting nested parentheses
  - Supporting integer operands only
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import javax.script.ScriptEngineManager;
import javax.script.ScriptEngine;
import javax.script.ScriptException;

public class PlexSysTest {
	
	public static void main(String[] args) {
		
		// Set debug log level
		try { logLevel = Integer.parseInt(args[0]); }
		catch (ArrayIndexOutOfBoundsException ex) { logLevel = 0; }
		catch (NumberFormatException ex) { logLevel = 0; }
		
		// Prompt for input and calculate answer
		System.out.println("Input expression (q to quit)");
		boolean go = true;
		while (go) {
			BufferedReader reader =  
				new BufferedReader(new InputStreamReader(System.in)); 
			try {
				System.out.print("> \r");
				String line = reader.readLine();
				if (! line.contentEquals("q")) {
					PlexSysTest pTest = new PlexSysTest();
					pTest.process(line);
				} else { go = false; }
			}
			catch (IOException ex) {
				// Problem reading/writing
				System.err.println("main() " + ex);
				System.err.println("Exiting");
				System.exit(-1);
			}
		}
	}

	// Debug log level
    private static int logLevel = 10;
    // Depending on parentheses, input line is split into pieces of these types
	private enum Type {
		GROUP,
		NEITHER,
		LEADING_STAR,
		TRAILING_STAR,
		LEADING_PLUS,
		TRAILING_PLUS
	}
	// Group marker
	private final String MARK="@";
	private final String MARKER="@)";
	private final String SEPARATOR=";";
	
	// Process one line
	private void process(String line) {
		
		// Use JS engine to get correct answer, check expression syntax
		int correctAnswer = 0;
		try { correctAnswer = check(line); }
		catch (ScriptException ex) {
			// Malformed expression
			System.err.println("process() " + ex);
		}
		
		// Split input line
		String[] parts = split(line);
		
		// Evaluate its parts and check answer
		int answer = evaluate(parts);
		System.out.println("Output=" + answer);
		if (answer != correctAnswer) {
			System.err.println("ERROR: correct answer is " + correctAnswer);
		}		
	}
  
    // Split line into bare (not parenthesized) parts, assume no nested parentheses
    private String[] split(String line) {    	
		// Strip blank spaces
		line = line.replaceAll("\\s+", "");
		log(10, "split() line=" + line);
		
		// Mark parenthesized parts with a trailing @
		line = line.replaceAll("\\)", MARKER);
		log(10, "split() line=" + line);
		
		// Strip parentheses
    	String[] parts = line.split("\\(|\\)");
		log(10, "split() line=" + line);
		
		// Eliminate empty parts
		int j = 0;
		Vector<String> v = new Vector<String>();
		for (int i = 0; i < parts.length; i++) {
			log(10, "split() parts[" + i + "]=" + parts[i] + SEPARATOR);
			if (! parts[i].isBlank()) {
				v.add(parts[i]);
				log(10, "split() v[" + j + "]=" + v.get(j));
				j++;
			}
		}
		String[] p = v.toArray(new String[v.size()]);
    	return p;
    }
    
    // Evaluate expression as combination of its parts
    private int evaluate(String[] parts) {    	
    	// Assign a type to each partial expression
    	LinkedHashMap<String, Type> pieces = assignType(parts);
    	
    	// Rebuild expression without parentheses
    	String whole = rebuild(pieces);
    	
    	// Evaluate the rebuilt expression
    	int xval = sumsAndProducts(whole);
    	log(10, "evaluate() whole=" + whole + " xval=" + xval);
    	return xval;
    }
    
    // Assign a type to each partial expression
    private LinkedHashMap<String, Type> assignType(String[] parts) {    	
    	LinkedHashMap<String, Type> pieces = new LinkedHashMap<String, Type>();
    	for (int i = 0; i < parts.length; i++) {
    		int last = parts[i].length() - 1;
    		Type type = Type.NEITHER;
        	StringBuilder bare = new StringBuilder(parts[i]);
    		log(20, "assignType() parts[" + i + "]=" + parts[i] + SEPARATOR);
        	
        	// Part is one character long or less, no change
        	if (parts[i].length() < 2) {
        		type = Type.NEITHER;
        	}
        	else {
        		if (parts[i].lastIndexOf(MARK) == last) {
            		// Part is marked as group
    				type = Type.GROUP;
    				bare.deleteCharAt(last);
    				if (last > 1) { last--; }
    			}
        		
        		if (parts[i].indexOf("*") == 0) {
            		// Part has leading multiply
    				type = Type.LEADING_STAR;
    				bare.deleteCharAt(0);
    				if (last > 1) { last--; }
    			}
        		else if (parts[i].indexOf("+") == 0) {
        			// Part has leading add
    				type = Type.LEADING_PLUS;
    				bare.deleteCharAt(0);
    				if (last > 1) { last--; }
    			}    		
    			
        		if (parts[i].lastIndexOf("*") == last) {
        			// Part has trailing multiply
    				type = Type.TRAILING_STAR;
    				bare.deleteCharAt(last);
    				if (last > 1) { last--; }
    			}
        		else if (parts[i].lastIndexOf("+") == last) {
        			// Part has trailing add
    				type = Type.TRAILING_PLUS;
    				bare.deleteCharAt(last);
    				if (last > 1) { last--; }
    			}
        	}
    		// Store partial expressions and their types
    		String b = bare.toString();
    		pieces.put(b, type);
    		log(10, "assignType() parts[" + i + "]=" + parts[i] + " last=" + last +
    			" b=" + b + " type=" + type);
    	}
    	return pieces;
    }
    
    // Rebuild expression after collapsing parentheses (if any)
    private String rebuild(LinkedHashMap<String, Type> pieces) {    	
    	String newLine = "";
    	StringBuilder whole = new StringBuilder("");
    	LinkedHashMap<String, Type> p = new LinkedHashMap<String, Type>();
    	Iterator<Entry<String, Type>> it = pieces.entrySet().iterator();
    	
    	// Collapse parentheses if any
    	int terms = 0;
    	while (it.hasNext()) {
    		String key = "";
    		Entry<String, Type> pair = it.next();
    		StringBuilder x = new StringBuilder(pair.getKey());
    		Type t = pair.getValue();
    		if (t == Type.GROUP) {
    			// Part was parenthesized so evaluate it before putting it back
    			int value = sumsAndProducts(x.toString());
    			key = String.valueOf(value);
    			log(10, "rebuild() value=" + value);
    		}
    		else {
    			// Part had no parentheses so put it back literally
    			key = x.toString();
    			log(10, "rebuild() literal=" + x.toString());
    		}
    		// Prepend term counter to key to guarantee it's unique
    		key = String.valueOf(terms) + SEPARATOR + key;
			p.put(key, t);
    		terms++;
    		log(20, "rebuild() p=<" + key + ", " + p.get(key) + ">");
    	}
    	log (10, "rebuild() " + terms + " terms found");
    	
    	// Rebuild the expression
    	terms = 0;
    	it = p.entrySet().iterator();
    	while (it.hasNext()) {
    		terms++;
    		Entry<String, Type> pair = it.next();
    		String x = pair.getKey();
    		Type t = pair.getValue();
    		// Strip the term counter prefix before adding term back
    		int index = x.indexOf(SEPARATOR) + 1;
    		x = x.substring(index);
    		log(10, "rebuild() p=<" + x + ", " + t + ">");
			if (t == Type.NEITHER || t == Type.GROUP) {
    			whole.append(x);
    		}
    		if (t == Type.LEADING_STAR) {
    			whole.append("*");
    			whole.append(x);
    		}
    		if (t == Type.TRAILING_STAR) {
    			whole.append(x);
    			whole.append("*");
    		}
    		if (t == Type.LEADING_PLUS) {
    			whole.append("+");
    			whole.append(x);
    		}
    		if (t == Type.TRAILING_PLUS) {
    			whole.append(x);
    			whole.append("+");
    		}
    	}
    	newLine = whole.toString();
    	log(10, "rebuild() terms=" + terms + " newLine=" + newLine);
    	return newLine;
    }
    
    // Evaluate one bare expression, assuming no leading or trailing operator
    private int sumsAndProducts(String expression) {    	
    	int xval = 0;
    	String[] x = expression.split("\\+");
    	for (int i = 0; i < x.length; i++) {
    		String s = "";
    		// Products take precedence over sums
    		if (x[i].indexOf("*") < 0) {
    			xval += Integer.parseInt(x[i]);
    		}
    		else {
    			xval += products(x[i]);
    			s = "<"; 
    		}
    		log(10, "sumsAndProducts() x[" + i + "]=" + x[i] + s + " xval=" + xval);
    	}
    	return xval;
    }
    
    // Evaluate products
    private int products(String expression) {    	
    	int xval = 1;
    	String[] x = expression.split("\\*");
    	for (int i = 0; i < x.length; i++) {
    		xval *= Integer.parseInt(x[i]);
    		log(10, "products() x[" + i + "]=" + x[i] + " xval=" + xval);
    	}
    	return xval;
    }	
    
    // Use JavaScript engine to check answer
    private int check(String expression) throws ScriptException {    	
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("JavaScript");
		int answer= (int)engine.eval(expression);
		return answer;
    }
    
    // Debug logging
    private static void log(int level, String s) {
    	if (level < logLevel) { System.out.println(s); }
    }
}

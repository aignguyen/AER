if (mw.toolbar && mw.toolbar.addButtons) {
	mw.toolbar.addButtons({
    "imageFile": "//upload.wikimedia.org/wikipedia/en/c/c8/Button_redirect.png",
    "speedTip": "Redirect",
    "tagOpen": "#REDIRECT [[",
    "tagClose": "]]",
    "sampleText": "Insert text"
   }, {
    "imageFile": "//upload.wikimedia.org/wikipedia/commons/8/88/Btn_toolbar_enum.png",
    "speedTip": "# list",
    "tagOpen": "#",
    "tagClose": "\n",
    "sampleText": "list text"
   }, {
    "imageFile": "//upload.wikimedia.org/wikipedia/commons/1/11/Btn_toolbar_liste.png",
    "speedTip": "* item",
    "tagOpen": "*",
    "tagClose": "\n",
    "sampleText": "item text"
   }, {
    "imageFile": "//upload.wikimedia.org/wikipedia/commons/b/b4/Button_category03.png",
    "speedTip": "Category",
    "tagOpen": "[[Category:",
    "tagClose": wgPageName + "]]",
    "sampleText": "insert category"
   }, {
    "imageFile": "//upload.wikimedia.org/wikipedia/commons/3/3b/Button_template_alt.png",
    "speedTip": "{{Template}}",
    "tagOpen": "{{",
    "tagClose": "}}",
    "sampleText": "sofixit"
   }, {
    "imageFile": "//upload.wikimedia.org/wikipedia/commons/f/fd/Button_underline.png",
    "speedTip": "Underline",
    "tagOpen": "<u>",
    "tagClose": "</u>",
    "sampleText": "underline text"
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/en/c/c9/Button_strike.png",
     "speedTip": "Strike",
     "tagOpen": "<s>",
     "tagClose": "</s>",
     "sampleText": "strikeout text"
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/en/8/80/Button_upper_letter.png",
     "speedTip": "Superscript",
     "tagOpen": "<sup>",
     "tagClose": "</sup>",
     "sampleText": "Superscript text"
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/en/7/70/Button_lower_letter.png",
     "speedTip": "Subscript",
     "tagOpen": "<sub>",
     "tagClose": "</sub>",
     "sampleText": "Subscript text"
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/commons/1/17/Button_small_2.png",
     "speedTip": "small text",
     "tagOpen": "<small>",
     "tagClose": "</small>",
     "sampleText": "Small Text"
   }, {
     "imageFile": " //upload.wikimedia.org/wikipedia/commons/5/56/Button_big.png",
     "speedTip": "BIG text",
     "tagOpen": "<big>",
     "tagClose": "</big>",
     "sampleText": "big"
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/commons/7/79/Button_reflink.png",
     "speedTip": "<ref>",
     "tagOpen": "<ref>",
     "tagClose": "</ref>",
     "sampleText": "Insert reference material"
   }, {
     "imageFile":  "//upload.wikimedia.org/wikipedia/commons/a/a0/Button_references_alt.png",
     "speedTip": "Reference footer",
     "tagOpen": "<references/>",
     "tagClose": "",
     "sampleText": ""
   }, {
     "imageFile": "//upload.wikimedia.org/wikipedia/commons/f/fd/Button_blockquote.png",
     "speedTip": "block of quoted text",
     "tagOpen": "<blockquote>\n",
     "tagClose": "\n</blockquote>",
     "sampleText": "Block quote"
   }, {
     "imageFile":  "//upload.wikimedia.org/wikipedia/commons/e/ea/Button_align_left.png",
     "speedTip": "align left",
     "tagOpen": "<p style=\"text-align:left;\">",
     "tagClose": "</p>",
     "sampleText": "left text"
   }, {
     "imageFile":  "//upload.wikimedia.org/wikipedia/commons/5/5f/Button_center.png",
     "speedTip": "align center",
     "tagOpen": "<p style=\"text-align:center;\">",
     "tagClose": "</p>",
     "sampleText": "center text"
   }, {
     "imageFile":  "//upload.wikimedia.org/wikipedia/commons/a/a5/Button_align_right.png",
     "speedTip": "align right",
     "tagOpen": "<p style=\"text-align:right;\">",
     "tagClose": "</p>",
     "sampleText": "right text"
   });
}